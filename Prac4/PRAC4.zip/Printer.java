import java.util.concurrent.locks.Lock;
import java.util.concurrent.TimeUnit;



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////UNCOMMENT FOR TASK 1/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// public class Printer {
//     private final Lock l;
//     private final String[] queue;
//     private int size;
//     private int front;
//     private int rear;

//     public Printer(Lock l) {
//         this.l = l;
//         this.queue = new String[100];
//         this.size = 0;
//         this.front = 0;
//         this.rear = 0;
//     }

//     public void print(String document, String threadName, int requestNumber) {
//         String request = threadName + ":Request " + requestNumber;
//         System.out.println(request + " printing request");
//         ((MCSQueue)l).lock(requestNumber);
//         try {
//             if (size < queue.length) {
//                 queue[rear] = request;
//                 rear = (rear + 1) % queue.length;
//                 size++;
//                 //System.out.println(request + " added to the queue");
//             }
//             while (size > 0 && queue[front].equals(request)) {
//                 String nextRequest = queue[front];
//                 System.out.println(nextRequest + " printing hello world");
//                 Thread.sleep((long) (Math.random() * 800 + 200));
//                 front = (front + 1) % queue.length;
//                 size--;
//             }
//         } catch (InterruptedException e) {
//             e.printStackTrace();
//         } finally {
//             l.unlock();
//         }
//     }
// }




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////UNCOMMENT FOR TASK 2/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public class Printer {
    private final Timeout l;
    private final String[] queue;
    private int size;
    private int front;
    private int rear;

    public Printer(Timeout l) {
        this.l = l;
        this.queue = new String[100];
        this.size = 0;
        this.front = 0;
        this.rear = 0;
    }

    public void print(String document, String threadName, int requestNumber) {
        String request = threadName + ":Request " + requestNumber;
        System.out.println(request + " printing request");
        if (!l.tryLock(requestNumber)) {
            System.out.println(request + " timed out");
            return;
        }
        try {
            if (size < queue.length) {
                queue[rear] = request;
                rear = (rear + 1) % queue.length;
                size++;
            }
            while (size > 0 && queue[front].equals(request)) {
                String nextRequest = queue[front];
                System.out.println(nextRequest + " printing hello world");
                Thread.sleep((long) (Math.random() * 800 + 200));
                front = (front + 1) % queue.length;
                size--;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            l.unlock();
        }
    }
}