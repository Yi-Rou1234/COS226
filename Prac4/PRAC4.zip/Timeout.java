import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class Timeout implements Lock {
    private final AtomicReference<QNode> tail;
    private final ThreadLocal<QNode> myNode;
    private final long timeout;

    public Timeout(long timeout) {
        tail = new AtomicReference<>(null);
        myNode = new ThreadLocal<QNode>() {
            protected QNode initialValue() {
                return new QNode(Thread.currentThread().getName(), 0);
            }
        };
        this.timeout = timeout;
    }

    public boolean tryLock(int requestNumber) {
        QNode qnode = myNode.get();
        qnode.requestNumber = requestNumber;
        QNode pred = tail.getAndSet(qnode);
        if (pred != null) {
            qnode.locked = true;
            pred.next = qnode;
            long startTime = System.currentTimeMillis();
            while (qnode.locked) {
                if (System.currentTimeMillis() - startTime > timeout) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void lock() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void unlock() {
        QNode qnode = myNode.get();
        QNode move = qnode.next;
        System.out.print("QUEUE:");
        while(move!=null){
            System.out.print("{" + move.threadName + ":Request " + move.requestNumber + "}");
            if(move.next!=null){
                System.out.print("->");
            }
            move = move.next;
        }
        System.out.println();
        
        if (qnode.next == null) {
            if (tail.compareAndSet(qnode, null))
                return;
            while (qnode.next == null) {}
        }
        qnode.next.locked = false;
        qnode.next = null;
    }

    @Override
    public void lockInterruptibly() throws InterruptedException {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean tryLock() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
        throw new UnsupportedOperationException();
    }

    @Override
    public Condition newCondition() {
        throw new UnsupportedOperationException();
    }

    public class QNode {
        volatile boolean locked = false;
        volatile QNode next = null;
        String threadName;
        int requestNumber;

        QNode(String threadName, int requestNumber) {
            this.threadName = threadName;
            this.requestNumber = requestNumber;
        }
    }
}
