public class Main {
    public static void main(String[] args) {
        Crud crud = new Crud();
        crud.start();
    }   
}
