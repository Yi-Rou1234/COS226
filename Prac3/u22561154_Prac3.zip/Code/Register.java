//Yi-Rou Hung
//u22561154
public interface Register<T>{
    T read();
    void write(T value);
}