import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

class task2 implements Lock {
    //using bool to indicate whether thread is in critical section or not
    private boolean[] flag = new boolean[2];
    // victim is used to determine which thread gets favour if both threads want to enter
    // critical section, the victim will be the one waiting
    private int victim;

    @Override
    //ensure mutual exclusion between 2 threads
    public void lock() {
        //getting both thread ids
        int id = getThreadId();
        int other = 1 - id;

        //set to true so it wants to enter the critical section
        flag[id] = true;
        //thread becomes current victim
        victim = id;
        
        //if flag[other] is true then it wants to enter critical section
        //if victim == id then it is not current victim, other thread gets preference
        while (flag[other] && victim == id) 
        {
            //current thread will wait until the other thread leaves the critical section
            //ensures mutual exclusion
        }
    }

    @Override
    public void unlock() {
        //method used to release lock, if flag = false then it doesn't want to be in critical section anymore
        //if this thread flag is unlocked then it allows the other thread to enter critical section 
        int id = getThreadId();
        flag[id] = false;
    }

    private int getThreadId() {
        return Thread.currentThread().getName().equals("Thread-0") ? 0 : 1;
    }

    //unused implemented functions
    @Override
    public void lockInterruptibly() throws InterruptedException {
        throw new UnsupportedOperationException("Not used");
    }

    @Override
    public boolean tryLock() {
        throw new UnsupportedOperationException("Not used");
    }

    @Override
    public boolean tryLock(long time, java.util.concurrent.TimeUnit unit) throws InterruptedException {
        throw new UnsupportedOperationException("Not used");
    }

    @Override
    public Condition newCondition() {
        throw new UnsupportedOperationException("Not used");
    }
}

class PrimeSearch implements Runnable {
    private final int[] array;
    private final int size;
    private final Lock lock;
    private static volatile int counter = 0;

    public PrimeSearch(int[] array, int size, Lock lock) {
        this.array = array;
        this.size = size;
        this.lock = lock;
    }

    public void run() {
        int current;
        while ((current = getAndIncrement()) < size) {
            if (isPrime(array[current])) {
                System.out.println(Thread.currentThread().getName() + " [" + current + "]: " + array[current]);
            }
        }
    }

    private boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }

        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }

        return true; 
    }

    private int getAndIncrement() {
        lock.lock();
        try {
            int value = counter;
            if (value >= size) {
                return size;
            }
            counter++;
            return value;
        } finally {
            lock.unlock();
        }
    }
}