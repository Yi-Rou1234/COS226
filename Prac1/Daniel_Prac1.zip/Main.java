import java.util.concurrent.locks.Lock;

class Main 
{
    public static void main(String[] args) 
    {
        task1();
        System.out.println("");
        task2();
    }

    static void task1() 
    {
        //range of numbers to check for prime
        int n = 1;
        int m = 100;

        int amountOfThreads = 4;

        //size of array
        int size = m - n + 1;
        Integer[] array = new Integer[size];
        //populating array
        for (int i = 0; i < size; i++) 
        {
            array[i] = n + i;
        }

        Thread[] threads = new Thread[amountOfThreads];

        int gapToCheck = size / amountOfThreads;
        int remainderAmount = size % amountOfThreads;

        int start = 0;
        int end;

        System.out.println("Task 1:");
        for (int i = 0; i < amountOfThreads; i++) 
        {
            end = start + gapToCheck - 1 + (remainderAmount-- > 0 ? 1 : 0);
            Runnable runnable = new myThread(array, start, end);
            threads[i] = new Thread(runnable, "Thread-" + i);
            threads[i].start();
            start = end + 1;
        }

        for (Thread thread : threads) 
        {
            try 
            {
                thread.join();
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
        }
    }

    static void task2() 
    {
        int n = 1; 
        int m = 10000; 
        int numThreads = 2; 

        int size = m - n + 1;
        int[] array = new int[size];
        for (int i = 0; i < size; i++) 
        {
            array[i] = n + i;
        }

        Lock lock = new task2();

        Thread[] threads = new Thread[numThreads];

        System.out.println("Task 2:");
        for (int i = 0; i < numThreads; i++) 
        {
            Runnable runnable = new PrimeSearch(array, size, lock);
            threads[i] = new Thread(runnable, "Thread-" + i);
            threads[i].start();
        }

        for (Thread thread : threads) 
        {
            try 
            {
                thread.join();
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
        }
    }
}